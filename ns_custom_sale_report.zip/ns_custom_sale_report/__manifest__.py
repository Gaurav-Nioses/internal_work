# -*- coding: utf-8 -*-

{
    'name': 'Sale Order  Custom',
    'version': '18.0',
    'category': '',
    'summary': 'Custom Module For Sale Order',
    'author': '',
    'website': '',
    'depends': ['base', 'sale','account'],
    'data': [
        "report/ns_custom_record.xml",
        "report/sale_order_report_template.xml",
        "report/ns_custom_invoice_report_nybci_template.xml",
        "report/ns_custom_warehouse_nbyci_template.xml",
    ],
    'license':'OPL-1',
    'installable': True,
    'auto_install': False,
}
