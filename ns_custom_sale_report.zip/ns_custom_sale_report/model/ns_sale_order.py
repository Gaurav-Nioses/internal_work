from odoo import api, fields, models, _

class NsSaleOrder(models.Model):
    _inherit = 'sale.order'
    
